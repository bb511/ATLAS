
/*
--------------- Day 5 ---------------
Soumya Shreeram and Patrick Odagiu -- 04/09/2018
Z boson Analysis

No slepion criteria, plots parameters to see where to cut.
*/

#ifndef MyAnalysis
#define MyAnalysis

// Include the file that lets the program know about the data.
#include "Headers/mini.h"
#include "TH1F.h"
#include <math.h>
#include <fstream>


void mini::Book(std::string choice){
	// h1 = new TH1F("My_Histogram_Name", "Title", number of bins, x_min, x_max);

	// Lepton number histogram
  	h_lep_n = new TH1F("Lepton_no", "Number of Leptons", 10, -0.5, 9.5);
  	h_lep_type = new TH1F("type", TString::Format("%s: lepton type",
  						  choice.c_str()), 20, 0.5, 20.5);

	// Parameter Histograms
  	h_lep_pt = new TH1F("pt", TString::Format("%s: Trans Momentum Pos",
  						    choice.c_str()), 100, 0, 60000);
  	h_lep_en  = new TH1F("en", TString::Format("%s: Energy Pos",
  						     choice.c_str()), 100, 0, 60000);
  	h_lep_ph  = new TH1F("ph", TString::Format("%s: Phi Pos",
  						     choice.c_str()), 100, -4, 4);
  	h_lep_et  = new TH1F("et", TString::Format("%s: Eta Pos",
  						     choice.c_str()), 100, 0, 2.7);
	}


void mini::FillHist(std::string choice){

	// Weight calculation --- PLEASE DO NOT CHANGE OR REMOVE!
	//////////////////////////////////////////////////////////////////////////
    std::unordered_map<std::string, double> ScaleFactor_Lumi = {
		{"Zee", 4.01173e-08},
		{"Zmumu", 4.41736e-08},
		{"Ztautau", 4.273775e-08},
		{"DYeeM08to15", 0.02162},
		{"DYeeM15to40", 0.0212436},
		{"DYmumuM08to15", 0.019266},
		{"DYmumuM15to40", 0.024265},
		{"WenuB",0.27983},
		{"WenuNoB", 0.907435},
		{"WenuNoBJets", 0.350585},
		{"WmunuB", 0.289016},
		{"WmunuNoB", 1.04169},
		{"WmunuNoBJets", 0.328063},
		{"WtaunuB", 0.18807},
		{"WtaunuNoB",0.920297 },
		{"WtaunuNoBJets", 0.343289},
		{"WW", 0.0216398},
		{"WZ", 0.00723487},
		{"ZZ", 0.00663601},
		{"ttLep", 0.0382083},
		{"ttHad", 0.0118436},
		{"ZPrime500", 0.03945},
		{"ggH4lep", 3.1687e-05},
		{"VBFH4lep", 2.84628e-06}
	};

	double Scale_factor, Event_weight, weight;

	if(choice=="Muons" || choice=="Electrons")
		{
			weight = 1;
		}
	else
		{
		 	// Calculate weights:
		   	Scale_factor = ScaleFactor_Lumi[choice] * scaleFactor_ELE * \
		   				   scaleFactor_MUON * scaleFactor_TRIGGER;
		 	Event_weight = scaleFactor_PILEUP * scaleFactor_ZVERTEX * mcWeight;
		 	weight = Scale_factor * Event_weight;
		}
    //////////////////////////////////////////////////////////////////////////
    // End of weight calculation



	// Declaring main variables
	int lep_neg = 0, lep_pos = 0;
	double pt, en, ph, et;
	
	// Number of leptons histogram
	h_lep_n->Fill(lep_n,weight);
	// Type of leptons histogram
	for(signed int idx=0; idx<lep_n; idx++)
		h_lep_type->Fill(lep_type[idx], weight);

	if (lep_n>=2){
		for(signed int idx=0; idx<lep_n; idx++){
			if(lep_type[idx] == 11){

				if (lep_charge[idx] == 1){
					pt = lep_pt[idx];
					en = lep_E[idx];
					ph = lep_phi[idx];
					et = lep_eta[idx];
					lep_pos++;
				}

				if (lep_charge[idx] == -1){
					pt = lep_pt[idx];
					en = lep_E[idx];
					ph = lep_phi[idx];
					et = lep_eta[idx];
					lep_neg++;
				}
			}
		}
		if(lep_pos >= 1 && lep_neg >= 1){
			h_lep_pt->Fill(pt,weight);
			h_lep_en->Fill(en,weight);
			h_lep_ph->Fill(ph,weight);
			h_lep_et->Fill(et,weight);
		}

	}

}

void GenerateTxtData(TH1F* histogram, std::string filename);
void mini::Style(std::string choice){

	GenerateTxtData(h_lep_n, choice + "Parameters_n");
	GenerateTxtData(h_lep_type, choice + "Parameters_type");

	GenerateTxtData(h_lep_pt, choice + "Parameters_pt");
	GenerateTxtData(h_lep_en, choice + "Parameters_en");
	GenerateTxtData(h_lep_ph, choice + "Parameters_ph");
	GenerateTxtData(h_lep_et, choice + "Parameters_et");

	// Write the histograms to the file:
	h_lep_n->Write();
	h_lep_type->Write();
	
	h_lep_pt->Write();
	h_lep_en->Write();
	h_lep_ph->Write();
	h_lep_et->Write();
}

///////////////////////////////////////////////////////////////////////////////
// EXTRA FUNCTIONS

struct integralInfo {
	double value;
	double error;
};

integralInfo IntegralHist(TH1F* histogram){
	// Function that returns the integral of the bins in a certain histogram
	double integral;
	int nbins;

	// Get the number of bins
	nbins = histogram->GetNbinsX();

	// Calculate the integral and the error
	Double_t error;
	integral = histogram->IntegralAndError(1, nbins, error);

	// Store the data in the integralInfo structure
	integralInfo integral_data;
	integral_data.value = integral;
	integral_data.error = error;

	return integral_data;
}

void GenerateTxtData(TH1F* histogram, std::string filename){
	// Function that generates the data stored in a histogram
	// Inside a text file

	ofstream myFile("OutputFiles/TextHistograms/" + filename + ".txt");
	myFile << "BinNo" << "\t"<< "Start" << "\t"<< "End" << "\t"<< "No" << endl;
	for (int idx=1; idx<=histogram->GetNbinsX(); idx++)
	{
    	myFile << idx << "\t" << \
		(double)(histogram->GetBinCenter(idx))- \
    	(double)(histogram->GetBinWidth(idx)/2.)<< "\t" << \
    	(double)(histogram->GetBinCenter(idx)) + \
    	(double)(histogram->GetBinWidth(idx)/2.) << "\t" << \
		(double)histogram->GetBinContent(idx) << endl;
	}
	integralInfo integral;
	integral = IntegralHist(histogram);
	myFile << endl << "Integral: " << integral.value << " ± " << integral.error \
		   << endl;
	myFile.close();
}


#endif
