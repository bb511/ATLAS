/*
--------------- Day 99 ---------------
Soumya Shreeram and Patrick Odagiu -- 27/09/2018
Calculates and plots a histograms of the 'invariant mass' of the lepton pair
due to decay of the Z boson at different ptcone and etcone values
This also creates a text file with the histogram

Selection criterias used: 1,2,3,4
*/

#ifndef MyAnalysis
#define MyAnalysis

// Include the file that lets the program know about the data.
#include "Headers/mini.h"
#include "TH1F.h"
#include <math.h>
#include <fstream>


void mini::Book(std::string choice){
	// h1 = new TH1F("My_Histogram_Name", "Title", number of bins, x_min, x_max);

	// Lepton number histogram
  	h_lep_n = new TH1F("Lepton_no", "Number of Leptons", 10, -0.5, 9.5);
  	h_lep_type = new TH1F("type", TString::Format("%s: lepton type",
  						  choice.c_str()), 20, 0.5, 20.5);

	// Invariant mass histograms
	h_lep_mass_3k = new TH1F("inv_mass_8k",
							 TString::Format("%s: Invariant Mass 8k",
						     choice.c_str()), 100, 70000, 125000);
	h_lep_mass_4k = new TH1F("inv_mass_4k",
							 TString::Format("%s: Invariant Mass 4k",
						     choice.c_str()), 100, 70000, 125000);
	h_lep_mass_5k = new TH1F("inv_mass_5k",
							 TString::Format("%s: Invariant Mass 5k",
						     choice.c_str()), 100, 70000, 125000);
	h_lep_mass_6k = new TH1F("inv_mass_6k",
							 TString::Format("%s: Invariant Mass 6k",
						     choice.c_str()), 100, 70000, 125000);
	h_lep_mass_7k = new TH1F("inv_mass_7k",
							 TString::Format("%s: Invariant Mass 7k",
						     choice.c_str()), 100, 70000, 125000);

	}


void mini::FillHist(std::string choice){

	// Weight calculation --- PLEASE DO NOT CHANGE OR REMOVE!
	//////////////////////////////////////////////////////////////////////////
    std::unordered_map<std::string, double> ScaleFactor_Lumi = {
		{"Zee", 4.01173e-08},
		{"Zmumu", 4.41736e-08},
		{"Ztautau", 4.273775e-08},
		{"DYeeM08to15", 0.02162},
		{"DYeeM15to40", 0.0212436},
		{"DYmumuM08to15", 0.019266},
		{"DYmumuM15to40", 0.024265},
		{"WenuB",0.27983},
		{"WenuNoB", 0.907435},
		{"WenuNoBJets", 0.350585},
		{"WmunuB", 0.289016},
		{"WmunuNoB", 1.04169},
		{"WmunuNoBJets", 0.328063},
		{"WtaunuB", 0.18807},
		{"WtaunuNoB",0.920297 },
		{"WtaunuNoBJets", 0.343289},
		{"WW", 0.0216398},
		{"WZ", 0.00723487},
		{"ZZ", 0.00663601},
		{"ttLep", 0.0382083},
		{"ttHad", 0.0118436},
		{"ZPrime500", 0.03945},
		{"ggH4lep", 3.1687e-05},
		{"VBFH4lep", 2.84628e-06}
	};

	double Scale_factor, Event_weight, weight;

	if(choice=="Muons" || choice=="Electrons")
		{
			weight = 1;
		}
	else
		{
		 	// Calculate weights:
		   	Scale_factor = ScaleFactor_Lumi[choice] * scaleFactor_ELE * \
		   				   scaleFactor_MUON * scaleFactor_TRIGGER;
		 	Event_weight = scaleFactor_PILEUP * scaleFactor_ZVERTEX * mcWeight;
		 	weight = Scale_factor * Event_weight;
		}
    //////////////////////////////////////////////////////////////////////////
    // End of weight calculation



	// Declaring variables
	int lep_neg, lep_pos;
	double ptplus, enplus, phplus, etplus;
	double ptminus, enminus, phminus, etminus;
	double max_ptplus, max_ptminus;
	double ptcones_pos, etcones_pos, ptcones_neg, etcones_neg;

	// Number of leptons histogram
	h_lep_n->Fill(lep_n,weight);
	// Type of leptons histogram
	for(signed int idx=0; idx<lep_n; idx++)
		h_lep_type->Fill(lep_type[idx], weight);


	// Selection code
	if(lep_n >= 2){
		for(int limit = 3000; limit <= 7000; limit += 1000){

			lep_neg = 0;
			lep_pos = 0;
			max_ptplus = -1;
			max_ptminus = -1;

			for (int idx = 0; idx < lep_n; idx++)
			{
				if (lep_type[idx] == 11 && lep_eta[idx] >= 1.6 && lep_eta[idx] <= 2.4)
					if(lep_pt[idx] >= 20000 && lep_E[idx] >=40000)
					if(lep_ptcone30[idx] < limit && 
					   lep_etcone20[idx] < limit){

						if (lep_charge[idx] == 1)
							if (lep_pt[idx] > max_ptplus)
							{
								ptplus = lep_pt[idx];
								enplus = lep_E[idx];
								phplus = lep_phi[idx];
								etplus = lep_eta[idx];
								max_ptplus = lep_pt[idx];
								lep_pos++;
							}
						if (lep_charge[idx] == -1)
							if(lep_pt[idx] > max_ptminus)
							{
								ptminus = lep_pt[idx];
								enminus = lep_E[idx];
								phminus = lep_phi[idx];
								etminus = lep_eta[idx];
								max_ptminus = lep_pt[idx];
								lep_neg++;
							}
					}
			}

			if(lep_pos >= 1 && lep_neg >= 1)
			{
				double pxminus = ptminus*cos(phminus);
				double pyminus = ptminus*cos(phminus);
				double pzminus = ptminus*sinh(etminus);
				double pxplus = ptplus*cos(phplus);
				double pyplus = ptplus*cos(phplus);
				double pzplus = ptplus*sinh(etplus);

				double inv_mass = sqrt(pow((enminus + enplus), 2) -
									   pow((pxplus + pxminus), 2) -
									   pow((pyplus + pyminus), 2) -
									   pow((pzplus + pzminus), 2) );
				switch(limit)
				{
					case 3000: h_lep_mass_3k->Fill(inv_mass, weight);
							   break;
					case 4000: h_lep_mass_4k->Fill(inv_mass, weight);
							   break;
					case 5000: h_lep_mass_5k->Fill(inv_mass, weight);
							   break;
					case 6000: h_lep_mass_6k->Fill(inv_mass, weight);
							   break;
					case 7000: h_lep_mass_7k->Fill(inv_mass, weight);
							   break;
				}
			}

		}
	}

}

void GenerateTxtData(TH1F* histogram, std::string filename);
void mini::Style(std::string choice){

	// Makes a text file with the Z boson mass histogram
	GenerateTxtData(h_lep_mass_3k,choice + "Mass_3k");
	GenerateTxtData(h_lep_mass_4k,choice + "Mass_4k");
	GenerateTxtData(h_lep_mass_5k,choice + "Mass_5k");
	GenerateTxtData(h_lep_mass_6k,choice + "Mass_6k");
	GenerateTxtData(h_lep_mass_7k,choice + "Mass_7k");


	// Write the histograms to the file:
	h_lep_n->Write();
	h_lep_mass_3k->Write();
	h_lep_mass_4k->Write();
	h_lep_mass_5k->Write();
	h_lep_mass_6k->Write();
	h_lep_mass_7k->Write();
}

///////////////////////////////////////////////////////////////////////////////
// EXTRA FUNCTIONS


struct integralInfo {
	double value;
	double error;
};

integralInfo IntegralHist(TH1F* histogram){
	// Function that returns the integral of the bins in a certain histogram
	double integral;
	int nbins;

	// Get the number of bins
	nbins = histogram->GetNbinsX();

	// Calculate the integral and the error
	Double_t error;
	integral = histogram->IntegralAndError(1, nbins, error);

	// Store the data in the integralInfo structure
	integralInfo integral_data;
	integral_data.value = integral;
	integral_data.error = error;

	return integral_data;
}

void GenerateTxtData(TH1F* histogram, std::string filename){
	// Function that generates the data stored in a histogram
	// Inside a text file

	ofstream myFile("OutputFiles/TextHistograms/" + filename + ".txt");
	myFile << "BinNo" << "\t"<< "Start" << "\t"<< "End" << "\t"<< "No" << endl;
	for (int idx=1; idx<=histogram->GetNbinsX(); idx++)
	{
    	myFile << idx << "\t" << \
		(double)(histogram->GetBinCenter(idx))- \
    	(double)(histogram->GetBinWidth(idx)/2.)<< "\t" << \
    	(double)(histogram->GetBinCenter(idx)) + \
    	(double)(histogram->GetBinWidth(idx)/2.) << "\t" << \
		(double)histogram->GetBinContent(idx) << endl;
	}
	integralInfo integral;
	integral = IntegralHist(histogram);
	myFile << endl << "Integral: " << integral.value << " ± " << integral.error \
		   << endl;
	myFile.close();
}


#endif
