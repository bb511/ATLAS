
/*
--------------- Day 6 ---------------
Soumya Shreeram and Patrick Odagiu -- 11/10/2018
W boson Analysis
Cone plots

Selection criteria: 1,2,3,4
*/

#ifndef MyAnalysis
#define MyAnalysis

// Include the file that lets the program know about the data.
#include "Headers/mini.h"
#include "TH1F.h"
#include <math.h>
#include <fstream>


void mini::Book(std::string choice){
	// h1 = new TH1F("My_Histogram_Name", "Title", number of bins, x_min, x_max);

	// Lepton number histogram
  	h_lep_n = new TH1F("Lepton_no", "Number of Leptons", 10, -0.5, 9.5);
  	h_lep_type = new TH1F("type", TString::Format("%s: lepton type",
  						  choice.c_str()), 20, 0.5, 20.5);

	// Parameter Histograms
  	h_lep_mass_05k = new TH1F("mass_05k",
	  						  TString::Format("%s: mass_05k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_1k = new TH1F("mass_1k",
	  						  TString::Format("%s: mass_1k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_2k = new TH1F("mass_2k",
	  						  TString::Format("%s: mass_2k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_3k = new TH1F("mass_3k",
	  						  TString::Format("%s: mass_3k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_4k = new TH1F("mass_4k",
	  						  TString::Format("%s: mass_4k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_5k = new TH1F("mass_5k",
	  						  TString::Format("%s: mass_5k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_6k = new TH1F("mass_6k",
	  						  TString::Format("%s: mass_6k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_7k = new TH1F("mass_7k",
	  						  TString::Format("%s: mass_7k:",
	  						  choice.c_str()), 100, 40000, 100000);
  	h_lep_mass_8k = new TH1F("mass_8k",
	  						  TString::Format("%s: mass_8k:",
	  						  choice.c_str()), 100, 40000, 100000);
  }


void mini::FillHist(std::string choice){

	// Weight calculation --- PLEASE DO NOT CHANGE OR REMOVE!
	//////////////////////////////////////////////////////////////////////////
    std::unordered_map<std::string, double> ScaleFactor_Lumi = {
		{"Zee", 4.01173e-08},
		{"Zmumu", 4.41736e-08},
		{"Ztautau", 4.273775e-08},
		{"DYeeM08to15", 0.02162},
		{"DYeeM15to40", 0.0212436},
		{"DYmumuM08to15", 0.019266},
		{"DYmumuM15to40", 0.024265},
		{"WenuB",0.27983},
		{"WenuNoB", 0.907435},
		{"WenuNoBJets", 0.350585},
		{"WmunuB", 0.289016},
		{"WmunuNoB", 1.04169},
		{"WmunuNoBJets", 0.328063},
		{"WtaunuB", 0.18807},
		{"WtaunuNoB",0.920297 },
		{"WtaunuNoBJets", 0.343289},
		{"WW", 0.0216398},
		{"WZ", 0.00723487},
		{"ZZ", 0.00663601},
		{"ttLep", 0.0382083},
		{"ttHad", 0.0118436},
		{"ZPrime500", 0.03945},
		{"ggH4lep", 3.1687e-05},
		{"VBFH4lep", 2.84628e-06}
	};

	double Scale_factor, Event_weight, weight;

	if(choice=="Muons" || choice=="Electrons")
		{
			weight = 1;
		}
	else
		{
		 	// Calculate weights:
		   	Scale_factor = ScaleFactor_Lumi[choice] * scaleFactor_ELE * \
		   				   scaleFactor_MUON * scaleFactor_TRIGGER;
		 	Event_weight = scaleFactor_PILEUP * scaleFactor_ZVERTEX * mcWeight;
		 	weight = Scale_factor * Event_weight;
		}
    //////////////////////////////////////////////////////////////////////////
    // End of weight calculation



	// Declaring main variables
	double etmiss, pt, Tmass;
	double delphi = 0, delphi_aux;

	// Number of leptons histogram
	h_lep_n->Fill(lep_n,weight);
	// Type of leptons histogram
	for(signed int idx=0; idx<lep_n; idx++)
		h_lep_type->Fill(lep_type[idx], weight);

	if (lep_n>=1){
		etmiss = met_et;
		for(int limit = 500; limit<=8000; limit += 1000){

			if(limit==1500)
				limit = 1000;

			for(signed int idx=0; idx<lep_n; idx++){
				if(lep_type[idx] == 13)
					if(lep_pt[idx] >= 25500 && met_et >= 35500)
						if(lep_ptcone30[idx] <= limit &&
						   lep_etcone20[idx] <= limit){

							delphi_aux = met_phi - lep_phi[idx];
							if(abs(delphi_aux) > abs(delphi)){

								delphi = delphi_aux;
								pt = lep_pt[idx];
							}
						}
			}
			Tmass = sqrt(2*etmiss*pt*cos(1-delphi));
			switch(limit){

				case 500: h_lep_mass_05k->Fill(Tmass,weight);
						  break;
				case 1000: h_lep_mass_1k->Fill(Tmass,weight);
						   break;
				case 2000: h_lep_mass_2k->Fill(Tmass,weight);
						   break;
				case 3000: h_lep_mass_3k->Fill(Tmass,weight);
						   break;
				case 4000: h_lep_mass_4k->Fill(Tmass,weight);
						   break;
				case 5000: h_lep_mass_5k->Fill(Tmass,weight);
						   break;
				case 6000: h_lep_mass_6k->Fill(Tmass,weight);
						   break;
				case 7000: h_lep_mass_7k->Fill(Tmass,weight);
						   break;
				case 8000: h_lep_mass_8k->Fill(Tmass,weight);
						   break;
			}

		}
	}

}

void GenerateTxtData(TH1F* histogram, std::string filename);
void mini::Style(std::string choice){

	GenerateTxtData(h_lep_mass_05k, choice + "Mass_05k");
	GenerateTxtData(h_lep_mass_1k, choice + "Mass_1k");
	GenerateTxtData(h_lep_mass_2k, choice + "Mass_2k");
	GenerateTxtData(h_lep_mass_3k, choice + "Mass_3k");
	GenerateTxtData(h_lep_mass_4k, choice + "Mass_4k");
	GenerateTxtData(h_lep_mass_5k, choice + "Mass_5k");
	GenerateTxtData(h_lep_mass_6k, choice + "Mass_6k");
	GenerateTxtData(h_lep_mass_7k, choice + "Mass_7k");
	GenerateTxtData(h_lep_mass_8k, choice + "Mass_8k");

	// Write the histograms to the file:
	h_lep_n->Write();
	h_lep_type->Write();
	TH1F* h_lep_mass_05k;
	TH1F* h_lep_mass_1k;
	TH1F* h_lep_mass_2k;
	TH1F* h_lep_mass_3k;
	TH1F* h_lep_mass_4k;
	TH1F* h_lep_mass_5k;
	TH1F* h_lep_mass_6k;
	TH1F* h_lep_mass_7k;
	TH1F* h_lep_mass_8k;
}

///////////////////////////////////////////////////////////////////////////////
// EXTRA FUNCTIONS

struct integralInfo {
	double value;
	double error;
};

integralInfo IntegralHist(TH1F* histogram){
	// Function that returns the integral of the bins in a certain histogram
	double integral;
	int nbins;

	// Get the number of bins
	nbins = histogram->GetNbinsX();

	// Calculate the integral and the error
	Double_t error;
	integral = histogram->IntegralAndError(1, nbins, error);

	// Store the data in the integralInfo structure
	integralInfo integral_data;
	integral_data.value = integral;
	integral_data.error = error;

	return integral_data;
}

void GenerateTxtData(TH1F* histogram, std::string filename){
	// Function that generates the data stored in a histogram
	// Inside a text file

	ofstream myFile("OutputFiles/TextHistograms/" + filename + ".txt");
	myFile << "BinNo" << "\t"<< "Start" << "\t"<< "End" << "\t"<< "No" << endl;
	for (int idx=1; idx<=histogram->GetNbinsX(); idx++)
	{
    	myFile << idx << "\t" << \
		(double)(histogram->GetBinCenter(idx))- \
    	(double)(histogram->GetBinWidth(idx)/2.)<< "\t" << \
    	(double)(histogram->GetBinCenter(idx)) + \
    	(double)(histogram->GetBinWidth(idx)/2.) << "\t" << \
		(double)histogram->GetBinContent(idx) << endl;
	}
	integralInfo integral;
	integral = IntegralHist(histogram);
	myFile << endl << "Integral: " << integral.value << " ± " << integral.error \
		   << endl;
	myFile.close();
}


#endif
