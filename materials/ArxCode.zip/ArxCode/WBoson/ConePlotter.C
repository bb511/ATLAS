
/*
--------------- Day 6 ---------------
Soumya Shreeram and Patrick Odagiu -- 11/10/2018
W boson Analysis
Cone plots

Selection criteria: 1,2,3,4
*/

#ifndef MyAnalysis
#define MyAnalysis

// Include the file that lets the program know about the data.
#include "Headers/mini.h"
#include "TH1F.h"
#include <math.h>
#include <fstream>


void mini::Book(std::string choice){
	// h1 = new TH1F("My_Histogram_Name", "Title", number of bins, x_min, x_max);

	// Lepton number histogram
  	h_lep_n = new TH1F("Lepton_no", "Number of Leptons", 10, -0.5, 9.5);
  	h_lep_type = new TH1F("type", TString::Format("%s: lepton type",
  						  choice.c_str()), 20, 0.5, 20.5);

	// Parameter Histograms
  	h_lep_ptcones = new TH1F("pt_cones",
  							 TString::Format("%s: pT Cones:",
  						     choice.c_str()), 100, 0, 60000);
  	h_lep_etcones = new TH1F("et_cones",
  							 TString::Format("%s: eT Cones:",
  						     choice.c_str()), 100, 0, 60000);
	}


void mini::FillHist(std::string choice){

	// Weight calculation --- PLEASE DO NOT CHANGE OR REMOVE!
	//////////////////////////////////////////////////////////////////////////
    std::unordered_map<std::string, double> ScaleFactor_Lumi = {
		{"Zee", 4.01173e-08},
		{"Zmumu", 4.41736e-08},
		{"Ztautau", 4.273775e-08},
		{"DYeeM08to15", 0.02162},
		{"DYeeM15to40", 0.0212436},
		{"DYmumuM08to15", 0.019266},
		{"DYmumuM15to40", 0.024265},
		{"WenuB",0.27983},
		{"WenuNoB", 0.907435},
		{"WenuNoBJets", 0.350585},
		{"WmunuB", 0.289016},
		{"WmunuNoB", 1.04169},
		{"WmunuNoBJets", 0.328063},
		{"WtaunuB", 0.18807},
		{"WtaunuNoB",0.920297 },
		{"WtaunuNoBJets", 0.343289},
		{"WW", 0.0216398},
		{"WZ", 0.00723487},
		{"ZZ", 0.00663601},
		{"ttLep", 0.0382083},
		{"ttHad", 0.0118436},
		{"ZPrime500", 0.03945},
		{"ggH4lep", 3.1687e-05},
		{"VBFH4lep", 2.84628e-06}
	};

	double Scale_factor, Event_weight, weight;

	if(choice=="Muons" || choice=="Electrons")
		{
			weight = 1;
		}
	else
		{
		 	// Calculate weights:
		   	Scale_factor = ScaleFactor_Lumi[choice] * scaleFactor_ELE * \
		   				   scaleFactor_MUON * scaleFactor_TRIGGER;
		 	Event_weight = scaleFactor_PILEUP * scaleFactor_ZVERTEX * mcWeight;
		 	weight = Scale_factor * Event_weight;
		}
    //////////////////////////////////////////////////////////////////////////
    // End of weight calculation



	// Declaring main variables
	int lep_neg = 0, lep_pos = 0;
	double ptconePlus, ptconeMinus, etconePlus, etconeMinus;
	double max_ptplus = -1, max_ptminus = -1;

	// Number of leptons histogram
	h_lep_n->Fill(lep_n,weight);
	// Type of leptons histogram
	for(signed int idx=0; idx<lep_n; idx++)
		h_lep_type->Fill(lep_type[idx], weight);

	if (lep_n >= 2){
		for(signed int idx=0; idx<lep_n; idx++){
			if(lep_type[idx] == 13){
				if (lep_charge[idx] == 1){
					if (lep_pt[idx] > max_ptplus){
						ptconePlus = lep_ptcone30[idx];
						etconePlus = lep_etcone20[idx];
						max_ptplus = lep_pt[idx];
						lep_pos++;
					}
				}
				if (lep_charge[idx] == -1){
					if (lep_pt[idx] > max_ptminus){
						ptconeMinus = lep_ptcone30[idx];
						etconeMinus = lep_etcone20[idx];
						max_ptminus = lep_pt[idx];
						lep_neg++;
					}
				}
			}
		}
		if(lep_neg >= 1 && lep_pos >= 1){
			h_lep_etcones->Fill(etconePlus,weight);
			h_lep_ptcones->Fill(ptconePlus,weight);
			h_lep_etcones->Fill(etconeMinus,weight);
			h_lep_ptcones->Fill(ptconeMinus,weight);
		}
	}

}

void GenerateTxtData(TH1F* histogram, std::string filename);
void mini::Style(std::string choice){

	GenerateTxtData(h_lep_etcones, choice + "_etcones");
	GenerateTxtData(h_lep_ptcones, choice + "_ptcones");

	// Write the histograms to the file:
	h_lep_n->Write();
	h_lep_type->Write();
	h_lep_etcones->Write();
	h_lep_ptcones->Write();
}

///////////////////////////////////////////////////////////////////////////////
// EXTRA FUNCTIONS

struct integralInfo {
	double value;
	double error;
};

integralInfo IntegralHist(TH1F* histogram){
	// Function that returns the integral of the bins in a certain histogram
	double integral;
	int nbins;

	// Get the number of bins
	nbins = histogram->GetNbinsX();

	// Calculate the integral and the error
	Double_t error;
	integral = histogram->IntegralAndError(1, nbins, error);

	// Store the data in the integralInfo structure
	integralInfo integral_data;
	integral_data.value = integral;
	integral_data.error = error;

	return integral_data;
}

void GenerateTxtData(TH1F* histogram, std::string filename){
	// Function that generates the data stored in a histogram
	// Inside a text file

	ofstream myFile("OutputFiles/TextHistograms/" + filename + ".txt");
	myFile << "BinNo" << "\t"<< "Start" << "\t"<< "End" << "\t"<< "No" << endl;
	for (int idx=1; idx<=histogram->GetNbinsX(); idx++)
	{
    	myFile << idx << "\t" << \
		(double)(histogram->GetBinCenter(idx))- \
    	(double)(histogram->GetBinWidth(idx)/2.)<< "\t" << \
    	(double)(histogram->GetBinCenter(idx)) + \
    	(double)(histogram->GetBinWidth(idx)/2.) << "\t" << \
		(double)histogram->GetBinContent(idx) << endl;
	}
	integralInfo integral;
	integral = IntegralHist(histogram);
	myFile << endl << "Integral: " << integral.value << " ± " << integral.error \
		   << endl;
	myFile.close();
}


#endif
